<?php

/** Irregular Words

$irregularWords = array(
	'singular' => 'plural' 
);
 
**/

$irregularWords = array(

);