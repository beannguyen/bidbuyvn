-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 01, 2014 at 12:33 PM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bidbuy`
--

-- --------------------------------------------------------

--
-- Table structure for table `bbv_commentmeta`
--

CREATE TABLE IF NOT EXISTS `bbv_commentmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bbv_comments`
--

CREATE TABLE IF NOT EXISTS `bbv_comments` (
`comment_ID` bigint(20) unsigned NOT NULL,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=89 ;

-- --------------------------------------------------------

--
-- Table structure for table `bbv_login_attempts`
--

CREATE TABLE IF NOT EXISTS `bbv_login_attempts` (
  `user_id` bigint(20) unsigned NOT NULL,
  `time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bbv_login_confirm`
--

CREATE TABLE IF NOT EXISTS `bbv_login_confirm` (
`id` int(11) NOT NULL,
  `data` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `type` varchar(25) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `bbv_login_confirm`
--

INSERT INTO `bbv_login_confirm` (`id`, `data`, `username`, `email`, `key`, `type`) VALUES
(1, '', 'spamer', 'spamerprovai@gmail.com', '8b7b9837ae4ddd179615311154b22b78', 'new_user');

-- --------------------------------------------------------

--
-- Table structure for table `bbv_login_integration`
--

CREATE TABLE IF NOT EXISTS `bbv_login_integration` (
  `user_id` int(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `google` varchar(255) NOT NULL,
  `yahoo` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bbv_login_levels`
--

CREATE TABLE IF NOT EXISTS `bbv_login_levels` (
`id` int(11) NOT NULL,
  `level_name` varchar(255) NOT NULL,
  `level_level` int(1) NOT NULL,
  `level_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `redirect` varchar(255) DEFAULT NULL,
  `welcome_email` tinyint(1) NOT NULL DEFAULT '0',
  `permission` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `bbv_login_levels`
--

INSERT INTO `bbv_login_levels` (`id`, `level_name`, `level_level`, `level_disabled`, `redirect`, `welcome_email`, `permission`) VALUES
(1, 'Admin', 1, 0, NULL, 0, 16777215),
(2, 'Seller', 2, 0, NULL, 0, 7028749),
(3, 'Buyer', 3, 0, NULL, 0, 6291469);

-- --------------------------------------------------------

--
-- Table structure for table `bbv_login_timestamps`
--

CREATE TABLE IF NOT EXISTS `bbv_login_timestamps` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bbv_login_users`
--

CREATE TABLE IF NOT EXISTS `bbv_login_users` (
`user_id` bigint(20) NOT NULL,
  `user_level` longtext NOT NULL,
  `restricted` int(1) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(128) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `bbv_login_users`
--

INSERT INTO `bbv_login_users` (`user_id`, `user_level`, `restricted`, `username`, `name`, `email`, `password`, `timestamp`) VALUES
(1, 'a:1:{i:0;s:1:"1";}', 0, 'admin', 'Administrator', 'vmod.game@gmail.com', '3b94a7bb9b911552d97cb87259ed8587', '2014-05-31 14:49:17'),
(12, 'a:1:{i:0;i:2;}', 1, 'boypro3666', 'Bean Nguyen', 'beanchanel@gmail.com', '3b94a7bb9b911552d97cb87259ed8587', '2014-10-18 17:00:04'),
(13, 'a:1:{i:0;i:2;}', 0, 'spamer', 'Le Luan', 'spamerprovai@gmail.com', '25d55ad283aa400af464c76d713c07ad', '2014-10-31 14:20:36');

-- --------------------------------------------------------

--
-- Table structure for table `bbv_members_meta`
--

CREATE TABLE IF NOT EXISTS `bbv_members_meta` (
`umeta_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `bbv_members_meta`
--

INSERT INTO `bbv_members_meta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'email', 'admin1@localhost.com'),
(2, 1, 'date_of_birth', '20051994'),
(3, 1, 'sex', 'M'),
(4, 1, 'phone_num', '0985962875'),
(5, 1, 'job_title', 'WebDeveloper'),
(6, 1, 'website_url', 'http://izstore.net'),
(7, 1, 'yahoo_im', 'daokiemvotinh_19942001'),
(8, 1, 'skype', 'dracubin94'),
(9, 1, 'about', 'Toi la admin trang nay, xin chao tat ca cac ban.\n\nTruy cap kimdiaoc.com.vn'),
(29, 12, 'sex', 'M'),
(30, 12, 'date_of_birth', '20/12/1994'),
(31, 12, 'phone_num', '0986464357'),
(32, 12, 'address', '42 Man Thien'),
(33, 12, 'city', 'Ho Chi Minh'),
(34, 12, 'country', 'vn'),
(35, 13, 'sex', 'M'),
(36, 13, 'date_of_birth', '22112000'),
(37, 13, 'phone_num', '0987651231'),
(38, 13, 'address', '42 Man Thien'),
(39, 13, 'city', 'HCM'),
(40, 13, 'country', 'vn'),
(41, 13, 'job_title', 'Kinh Doanh'),
(42, 13, 'website_url', ''),
(43, 13, 'yahoo_im', 'daokiemvotinh_19942001'),
(44, 13, 'skype', ''),
(45, 13, 'about', '');

-- --------------------------------------------------------

--
-- Table structure for table `bbv_options`
--

CREATE TABLE IF NOT EXISTS `bbv_options` (
`option_id` bigint(20) unsigned NOT NULL,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7173 ;

--
-- Dumping data for table `bbv_options`
--

INSERT INTO `bbv_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(7090, 'site_address', 'http://localhost/batdongsan', 'yes'),
(7103, 'default_session', '0', 'yes'),
(7093, 'admin_email', 'hls.engineering.group@gmail.com', 'yes'),
(7095, 'mailserver_url', 'smtp.gmail.com', 'yes'),
(7096, 'mailserver_login', 'hls.engineering.group@gmail.com', 'yes'),
(7097, 'mailserver_pass', 'hls123456', 'yes'),
(7098, 'mailserver_port', '465', 'yes'),
(7099, 'profile-timestamps-admin-enable', '1', 'yes'),
(7100, 'profile-timestamps-enable', '0', 'yes'),
(7101, 'guest-redirect', 'http://localhost/batdongsan/dashboard/login', 'yes'),
(7102, 'site_name', 'Kimdiaoc.com.vn', 'yes'),
(7104, 'block-msg-enable', 'on', 'yes'),
(7105, 'block-msg', '&lt;h1&gt;Sorry, Hank.&lt;/h1&gt;\r\n\r\n&lt;p&gt;We have detected that your user level does not entitle you to view the page requested.&lt;/p&gt;\r\n\r\n&lt;p&gt;Please contact the website administrator if you feel this is in error.&lt;/p&gt;\r\n\r\n&lt;h5&gt;What to do now?&lt;/h5&gt;\r\n&lt;p&gt;To see this page you must &lt;a href=''logout.php''&gt;logout&lt;/a&gt; and login with sufficiant privileges.&lt;/p&gt;', 'yes'),
(7106, 'block-msg-out', 'Bạn phải đăng nhập để thực hiện thao tác này!', 'yes'),
(7107, 'block-msg-out-enable', 'on', 'yes'),
(7108, 'email-welcome-msg', 'Xin chào {{full_name}} !\r\n\r\nThanks for registering at {{site_address}}. Here are your account details:\r\n\r\nName: {{full_name}}\r\nUsername: {{username}}\r\nEmail: {{email}}\r\nPassword: *hidden*\r\n\r\nYou will first have to activate your account by clicking on the following link:\r\n\r\n{{activate}}', 'yes'),
(7109, 'email-activate-msg', 'Hi there {{full_name}} !\r\n\r\nYour account at {{site_address}} has been successfully activated :). \r\n\r\nFor your reference, your username is &lt;strong&gt;{{username}}&lt;/strong&gt;. \r\n\r\nSee you soon!', 'yes'),
(7110, 'email-activate-subj', 'You''ve activated your account at Jigowatt !', 'yes'),
(7111, 'email-activate-resend-subj', 'Here''s your activation link again for Jigowatt', 'yes'),
(7112, 'email-activate-resend-msg', 'Why hello, {{full_name}}. \r\n\r\nI believe you requested this:\r\n{{activate}}\r\n\r\nClick the link above to activate your account :)', 'yes'),
(7113, 'email-welcome-subj', 'Chào mừng bạn đến với KimDiaOc.com.vn', 'yes'),
(7114, 'email-forgot-success-subj', 'Your password has been reset at Jigowatt', 'yes'),
(7115, 'email-forgot-success-msg', 'Welcome back, {{full_name}} !\r\n\r\nI''m just letting you know your password at {{site_address}} has been successfully changed. \r\n\r\nHopefully you were the one that requested this password reset !\r\n\r\nCheers', 'yes'),
(7116, 'email-forgot-subj', 'Thay đổi mật khấu trên hệ thống kimdiaoc.com.vn', 'yes'),
(7117, 'email-forgot-msg', 'Chào {{full_name}},\r\n\r\nTên đăng nhập của bạn là: &lt;strong&gt;{{username}}&lt;/strong&gt;.\r\n\r\nHệ thống đã tự động đổi mật khẩu của bạn thành: &lt;strong&gt;{{reset}}&lt;/strong&gt;\r\nHãy đăng nhập vào hệ thống &lt;em&gt;&lt;a href=&quot;{{site_address}}&quot;&gt;{{site_address}}&lt;/a&gt;&lt;em&gt; để đổi mật khẩu mới để đảm bảo tính bảo mật tài khoản!\r\n\r\nCảm ơn!', 'yes'),
(7118, 'email-add-user-subj', 'You''re registered with Jigowatt !', 'yes'),
(7119, 'email-add-user-msg', 'Hello {{full_name}} !\r\n\r\nYou''re now registered at {{site_address}}. Here are your account details:\r\n\r\nName: {{full_name}}\r\nUsername: {{username}}\r\nEmail: {{email}}\r\nPassword: {{password}}', 'yes'),
(7120, 'pw-encrypt-force-enable', '1', 'yes'),
(7121, 'pw-encryption', 'MD5', 'yes'),
(7122, 'phplogin_db_version', '1212300', 'yes'),
(7123, 'email-acct-update-subj', 'Confirm your account changes', 'yes'),
(7124, 'email-acct-update-msg', 'Hi {{full_name}} !\r\n\r\nYou ( {{username}} ) requested a change to update your password or email. Click the link below to confirm this change.\r\n\r\n{{confirm}}\r\n\r\nThanks!\r\n{{site_address}}', 'yes'),
(7125, 'email-acct-update-success-subj', 'Your account has been updated', 'yes'),
(7126, 'email-acct-update-success-msg', 'Hello {{full_name}},\r\n\r\nYour account details at {{site_address}} has been updated. \r\n\r\nYour username: {{username}}\r\n\r\nSee you around!', 'yes'),
(7127, 'signout-redirect-referrer-enable', '0', 'yes'),
(7128, 'signin-redirect-referrer-enable', '0', 'yes'),
(7129, 'default-level', 'a:1:{i:0;s:1:"3";}', 'yes'),
(7130, 'new-user-redirect', 'http://localhost/login-system/profile.php', 'yes'),
(7131, 'user-activation-enable', '0', 'yes'),
(7132, 'email-new-user-subj', 'A new user has registered !', 'yes'),
(7133, 'email-new-user-msg', 'Hello,\r\n\r\nThere''s been a new registration at &lt;a href=&quot;{{site_address}}&quot;&gt;your site&lt;/a&gt;.\r\n\r\nHere''s the user''s details:\r\n\r\nName: {{full_name}}\r\nUsername: {{username}}\r\nEmail: {{email}}', 'yes'),
(7134, 'email-as-username-enable', '0', 'yes'),
(7135, 'disable-logins-enable', '0', 'yes'),
(7136, 'restrict-signups-by-email', '', 'yes'),
(7137, 'signout-redirect-url', 'aaksdflk', 'yes'),
(7138, 'signin-redirect-url', '', 'yes'),
(7139, 'general-options-form', '1', 'yes'),
(7140, 'notify-new-user-enable', '0', 'yes'),
(7141, 'disable-registrations-enable', '0', 'yes'),
(7142, 'email-welcome-disable', '0', 'yes'),
(7143, 'integration-twitter-enable', '1', 'yes'),
(7144, 'twitter-key', '', 'yes'),
(7145, 'twitter-secret', '', 'yes'),
(7146, 'integration-facebook-enable', '1', 'yes'),
(7147, 'facebook-app-id', '', 'yes'),
(7148, 'facebook-app-secret', '', 'yes'),
(7149, 'integration-google-plus-enable', '1', 'yes'),
(7150, 'integration-yahoo-enable', '1', 'yes'),
(7151, 'reCAPTCHA-public-key', '', 'yes'),
(7152, 'reCAPTCHA-private-key', '', 'yes'),
(7153, 'playThru-publisher-key', '', 'yes'),
(7154, 'playThru-scoring-key', '', 'yes'),
(7155, 'integration-form', '1', 'yes'),
(7156, 'integration-captcha', 'disableCaptcha', 'yes'),
(7157, 'denied-form', '1', 'yes'),
(7158, 'user-profiles-form', '1', 'yes'),
(7159, 'update-form', '1', 'yes'),
(7160, 'update-check-enable', '0', 'yes'),
(7161, 'profile-display-email-enable', '0', 'yes'),
(7162, 'profile-display-name-enable', '0', 'yes'),
(7163, 'profile-public-enable', '1', 'yes'),
(7164, 'profile-field_section', 'a:2:{i:1;s:4:"Test";i:2;s:4:"Test";}', 'yes'),
(7165, 'profile-field_type', 'a:2:{i:1;s:10:"text_input";i:2;s:8:"textarea";}', 'yes'),
(7166, 'profile-field_name', 'a:2:{i:1;s:4:"test";i:2;s:10:"Gioi thieu";}', 'yes'),
(7167, 'profile-field_signup', 'a:2:{i:1;s:4:"hide";i:2;s:4:"hide";}', 'yes'),
(7168, 'profile-field_public', 'a:2:{i:1;s:2:"on";i:2;s:2:"on";}', 'yes'),
(7172, 'json_menu_list', '[{"id":1730,"children":[{"id":1713}]},{"id":1711},{"id":1713,"children":[{"id":1731}]},{"id":1732},{"id":1735,"children":[{"id":1734},{"id":1733,"children":[{"id":1736}]}]},{"id":1737}]', 'yes'),
(7169, 'notify-new-users', 'a:1:{i:0;s:1:"1";}', 'yes'),
(7171, 'site_title', 'Trang tin tức bất động sản', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `bbv_postmeta`
--

CREATE TABLE IF NOT EXISTS `bbv_postmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31039 ;

--
-- Dumping data for table `bbv_postmeta`
--

INSERT INTO `bbv_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(30421, 1767, 'post_viewer_count', '5'),
(30420, 1768, 'post_viewer_count', '1'),
(30418, 1768, 'feature_img', 'http://localhost/batdongsan/public/uploads/defaults/no-thumbnail.png'),
(30419, 1768, 'feature_img', 'http://localhost/batdongsan/public/uploads/defaults/no-thumbnail.png'),
(30417, 1767, 'feature_img', 'http://localhost/batdongsan/public/uploads/2014/10/16/sao-viet-ngay-cang-tao-bao-voi-mot-khoe-khe-nguc.jpg'),
(30416, 1767, 'feature_img', 'http://localhost/batdongsan/public/uploads/2014/10/16/sao-viet-ngay-cang-tao-bao-voi-mot-khoe-khe-nguc.jpg'),
(30415, 1766, 'post_viewer_count', '2'),
(30414, 1766, 'feature_img', 'http://localhost/batdongsan/public/uploads/2014/10/16/phong-vien-bbc-khen-ngoi-banh-mi-viet-nam-ngon-nhat-the-gioi.jpg'),
(30413, 1766, 'feature_img', 'http://localhost/batdongsan/public/uploads/2014/10/16/phong-vien-bbc-khen-ngoi-banh-mi-viet-nam-ngon-nhat-the-gioi.jpg'),
(30412, 1765, 'post_viewer_count', '5'),
(30411, 1765, 'feature_img', 'http://localhost/batdongsan/public/uploads/defaults/no-thumbnail.png'),
(30835, 1837, '_menu_item_url', 'http://localhost/batdongsan/category/muc-mac-dinh.html'),
(30834, 1837, '_menu_item_rang', '3'),
(30833, 1837, '_menu_item_object', 'category'),
(30832, 1837, '_menu_item_object_id', '1837'),
(30831, 1837, '_menu_item_menu_item_parent', '1836'),
(30830, 1837, '_menu_item_type', 'category'),
(30843, 1839, 'product_gallery', 'a:2:{i:0;s:111:"http://localhost/bidbuy/public/uploads/2014/10/25/doi-vo-chong-trong-buc-anh-na-son-chup-buc-xuc-len-tieng-.jpg";i:1;s:113:"http://localhost/bidbuy/public/uploads/2014/10/25/sao-viet-ngay-cang-tao-bao-voi-mot-khoe-khe-nguc-1414253014.jpg";}'),
(30842, 1839, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/25/ngo-ngang-vi-voc-dang-manh-mai-cua-elly-tran-khi-mang-thai.jpg'),
(30844, 1840, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/25/sao-viet-ngay-cang-tao-bao-voi-mot-khoe-khe-nguc-1414253587.jpg'),
(30845, 1840, 'product_gallery', 'a:2:{i:0;s:65:"http://localhost/bidbuy/public/uploads/2014/10/25/file.467146.jpg";i:1;s:122:"http://localhost/bidbuy/public/uploads/2014/10/25/doi-vo-chong-trong-buc-anh-na-son-chup-buc-xuc-len-tieng--1414253605.jpg";}'),
(30846, 1840, 'product_sku', '001'),
(30847, 1840, 'product_price', '100000'),
(30848, 1840, 'product_price_step', ''),
(30849, 1840, 'product_timeout', 'a:3:{i:0;s:1:&quot;0&quot;;i:1;s:1:&quot;1&quot;;i:2;s:2:&quot;60&quot;;}'),
(30850, 1841, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/25/phong-vien-bbc-khen-ngoi-banh-mi-viet-nam-ngon-nhat-the-gioi-1414253899.jpg'),
(30851, 1841, 'product_sku', '003'),
(30852, 1841, 'product_price', '10000'),
(30853, 1841, 'product_price_step', ''),
(30854, 1841, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"1";i:2;s:1:"0";}'),
(30855, 1842, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/25/phong-vien-bbc-khen-ngoi-banh-mi-viet-nam-ngon-nhat-the-gioi-1414261651.jpg'),
(30856, 1842, 'product_gallery', 'a:3:{i:0;s:123:"http://localhost/bidbuy/public/uploads/2014/10/25/ngo-ngang-vi-voc-dang-manh-mai-cua-elly-tran-khi-mang-thai-1414261662.jpg";i:1;s:125:"http://localhost/bidbuy/public/uploads/2014/10/25/phong-vien-bbc-khen-ngoi-banh-mi-viet-nam-ngon-nhat-the-gioi-1414261673.jpg";i:2;s:87:"http://localhost/bidbuy/public/uploads/2014/10/25/monster-demo-screens-1-1414261677.jpg";}'),
(30857, 1842, 'product_sku', 'A001'),
(30858, 1842, 'product_price', '200000'),
(30859, 1842, 'product_price_step', ''),
(30860, 1842, 'product_timeout', 'a:3:{i:0;s:1:"1";i:1;s:2:"14";i:2;s:1:"0";}'),
(30861, 1843, 'feature_img', '&lt;br /&gt;&lt;b&gt;Notice&lt;/b&gt;:  Undefined index: post_feature_img in &lt;b&gt;/opt/lampp/htdocs/bidbuy/application/views/dashboard/ecommerce/add-product.php&lt;/b&gt; on line &lt;b&gt;420&lt;/b&gt;&lt;br /&gt;'),
(30862, 1843, 'product_gallery', 'a:1:{i:0;s:102:"http://localhost/bidbuy/public/uploads/2014/10/26/sao-viet-ngay-cang-tao-bao-voi-mot-khoe-khe-nguc.jpg";}'),
(30867, 1844, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/26/doi-vo-chong-trong-buc-anh-na-son-chup-buc-xuc-len-tieng-.jpg'),
(30868, 1844, 'product_gallery', 'a:3:{i:0;s:113:"http://localhost/bidbuy/public/uploads/2014/10/26/sao-viet-ngay-cang-tao-bao-voi-mot-khoe-khe-nguc-1414291675.jpg";i:1;s:114:"http://localhost/bidbuy/public/uploads/2014/10/27/phong-vien-bbc-khen-ngoi-banh-mi-viet-nam-ngon-nhat-the-gioi.jpg";i:2;s:74:"http://localhost/bidbuy/public/uploads/2014/10/27/monster-demo-screens.jpg";}'),
(30863, 1843, 'product_sku', '123'),
(30864, 1843, 'product_price', '1200000'),
(30865, 1843, 'product_price_step', ''),
(30866, 1843, 'product_timeout', 'a:3:{i:0;s:1:"1";i:1;s:2:"23";i:2;s:2:"35";}'),
(30869, 1844, 'product_sku', 'A001'),
(30870, 1844, 'product_price', '100000'),
(30871, 1844, 'product_price_step', ''),
(30872, 1844, 'product_timeout', 'a:3:{i:0;s:1:"1";i:1;s:1:"0";i:2;s:1:"0";}'),
(30873, 1845, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/27/monster-demo-screens-1414373923.jpg'),
(30874, 1845, 'product_gallery', 'a:1:{i:0;s:111:"http://localhost/bidbuy/public/uploads/2014/10/27/doi-vo-chong-trong-buc-anh-na-son-chup-buc-xuc-len-tieng-.jpg";}'),
(30875, 1845, 'product_sku', 'A003'),
(30876, 1845, 'product_price', '1000000'),
(30877, 1845, 'product_price_step', ''),
(30878, 1845, 'product_timeout', 'a:3:{i:0;s:2:"13";i:1;s:2:"12";i:2;s:1:"0";}'),
(30879, 1846, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/29/sao-viet-ngay-cang-tao-bao-voi-mot-khoe-khe-nguc.jpg'),
(30880, 1846, 'product_gallery', 'a:2:{i:0;s:111:"http://localhost/bidbuy/public/uploads/2014/10/29/doi-vo-chong-trong-buc-anh-na-son-chup-buc-xuc-len-tieng-.jpg";i:1;s:113:"http://localhost/bidbuy/public/uploads/2014/10/29/sao-viet-ngay-cang-tao-bao-voi-mot-khoe-khe-nguc-1414574396.jpg";}'),
(30885, 1847, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/31/cm_b37903.jpg'),
(30881, 1846, 'product_sku', 'B110'),
(30882, 1846, 'product_price', '3000000'),
(30883, 1846, 'product_price_step', '500000'),
(30884, 1846, 'product_timeout', 'a:3:{i:0;s:1:"1";i:1;s:2:"12";i:2;s:1:"0";}'),
(30886, 1847, 'product_gallery', 'a:4:{i:0;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635496590495157859.jpg";i:1;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635496590786722371.jpg";i:2;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635496591377495408.jpg";i:3;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635496590964406683.jpg";}'),
(30887, 1847, 'product_sku', 'A001'),
(30888, 1847, 'product_price', '160000'),
(30889, 1847, 'product_price_step', '200000'),
(30890, 1847, 'product_timeout', 'a:3:{i:0;s:1:"2";i:1;s:2:"14";i:2;s:1:"0";}'),
(30891, 1847, 'product_top_bid', '0'),
(30892, 1848, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/31/cm_b38365.jpg'),
(30893, 1848, 'product_gallery', 'a:3:{i:0;s:100:"http://localhost/bidbuy/public/uploads/2014/10/31/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be (1).jpg";i:1;s:100:"http://localhost/bidbuy/public/uploads/2014/10/31/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be (2).jpg";i:2;s:100:"http://localhost/bidbuy/public/uploads/2014/10/31/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be (4).jpg";}'),
(30894, 1848, 'product_sku', 'A002'),
(30895, 1848, 'product_price', '125000'),
(30896, 1848, 'product_price_step', '200000'),
(30897, 1848, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:2:"12";i:2;s:1:"0";}'),
(30898, 1848, 'product_top_bid', '0'),
(30899, 1849, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/31/cm_b38552.jpg'),
(30900, 1849, 'product_gallery', 'a:3:{i:0;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635500246147702673.jpg";i:1;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/1635500246149730676.jpg";i:2;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/2635500246151602680.jpg";}'),
(30901, 1849, 'product_sku', 'A003'),
(30902, 1849, 'product_price', '189000'),
(30903, 1849, 'product_price_step', '200000'),
(30904, 1849, 'product_timeout', 'a:3:{i:0;s:1:"3";i:1;s:1:"0";i:2;s:1:"0";}'),
(30905, 1849, 'product_top_bid', '0'),
(30906, 1850, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/31/1635496719679140758.jpg'),
(30907, 1850, 'product_gallery', 'a:3:{i:0;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635496719677580755.jpg";i:1;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/2635496719681168762.jpg";i:2;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/3635496719682572764.jpg";}'),
(30908, 1850, 'product_sku', 'A004'),
(30909, 1850, 'product_price', '390000'),
(30910, 1850, 'product_price_step', '200000'),
(30911, 1850, 'product_timeout', 'a:3:{i:0;s:1:"5";i:1;s:2:"12";i:2;s:1:"0";}'),
(30912, 1850, 'product_top_bid', '0'),
(30913, 1851, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/31/0635465657071227494.jpg'),
(30914, 1851, 'product_gallery', 'a:5:{i:0;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/6635465657084799518.jpg";i:1;s:84:"http://localhost/bidbuy/public/uploads/2014/10/31/0635465657071227494-1414722108.jpg";i:2;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/1635465657073879499.jpg";i:3;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/2635465657076843504.jpg";i:4;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/3635465657079027508.jpg";}'),
(30915, 1851, 'product_sku', 'A005'),
(30916, 1851, 'product_price', '299000'),
(30917, 1851, 'product_price_step', '200000'),
(30918, 1851, 'product_timeout', 'a:3:{i:0;s:1:"1";i:1;s:2:"12";i:2;s:2:"11";}'),
(30919, 1851, 'product_top_bid', '0'),
(30920, 1852, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/31/0635497555041263994.jpg'),
(30921, 1852, 'product_gallery', 'a:4:{i:0;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635496704734314509.jpg";i:1;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/1635496704736030512.jpg";i:2;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/2635496704737434515.jpg";i:3;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/3635496704738838517.jpg";}'),
(30922, 1852, 'product_sku', 'A006'),
(30923, 1852, 'product_price', '350000'),
(30924, 1852, 'product_price_step', '200000'),
(30925, 1852, 'product_timeout', 'a:3:{i:0;s:1:"2";i:1;s:2:"12";i:2;s:2:"44";}'),
(30926, 1852, 'product_top_bid', '0'),
(30927, 1853, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/31/cm_b37017.jpg'),
(30928, 1853, 'product_gallery', 'a:4:{i:0;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635483586559733653.jpg";i:1;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635483586402017376.jpg";i:2;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635483586257093122.jpg";i:3;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635483586120436882.jpg";}'),
(30929, 1853, 'product_sku', 'A007'),
(30930, 1853, 'product_price', '395000'),
(30931, 1853, 'product_price_step', '200000'),
(30932, 1853, 'product_timeout', 'a:3:{i:0;s:2:"12";i:1;s:1:"1";i:2;s:2:"11";}'),
(30933, 1853, 'product_top_bid', '0'),
(30934, 1854, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/31/cm_b36366.jpg'),
(30935, 1854, 'product_gallery', 'a:4:{i:0;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635479436169011877.jpg";i:1;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635479436393496271.jpg";i:2;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/1635479436395212274.jpg";i:3;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/2635479436397396278.jpg";}'),
(30936, 1854, 'product_sku', 'A8'),
(30937, 1854, 'product_price', '69000'),
(30938, 1854, 'product_price_step', '200000'),
(30939, 1854, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:2:"23";i:2;s:2:"59";}'),
(30940, 1854, 'product_top_bid', '0'),
(30941, 1855, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/10/31/cm_b37312.jpg'),
(30942, 1855, 'product_gallery', 'a:3:{i:0;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635487938384249229.jpg";i:1;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/0635487938231524961.jpg";i:2;s:73:"http://localhost/bidbuy/public/uploads/2014/10/31/1635487938233396964.jpg";}'),
(30943, 1855, 'product_sku', 'S1123'),
(30944, 1855, 'product_price', '149000'),
(30945, 1855, 'product_price_step', '200000'),
(30946, 1855, 'product_timeout', 'a:3:{i:0;s:1:"1";i:1;s:2:"20";i:2;s:2:"11";}'),
(30947, 1855, 'product_top_bid', '0'),
(30948, 1847, 'product_end_date', '2014/11/03 14:19:43'),
(30949, 1848, 'product_end_date', '2014/11/01 12:21:22'),
(30950, 1849, 'product_end_date', '2014/11/04 09:55:22'),
(30951, 1855, 'product_end_date', '2014/11/03 06:11:14'),
(30952, 1856, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/cm_b37420.jpg'),
(30953, 1856, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635495684863647201.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635495684583938710.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635495684626526784.jpg";}'),
(30954, 1856, 'product_sku', 'S1000'),
(30955, 1856, 'product_price', '200000'),
(30956, 1856, 'product_price_step', '200000'),
(30957, 1856, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:1:"5";}'),
(30958, 1856, 'product_top_bid', '0'),
(30959, 1856, 'product_end_date', '2014/11/01 10:44:07'),
(30960, 1857, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/dep-bong-mang-trong-nha (2).jpg'),
(30961, 1857, 'product_sku', 'A00001'),
(30962, 1857, 'product_price', '29000'),
(30963, 1857, 'product_price_step', '200000'),
(30964, 1857, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"2";i:2;s:1:"0";}'),
(30965, 1857, 'product_top_bid', '0'),
(30966, 1857, 'product_gallery', 'a:3:{i:0;s:80:"http://localhost/bidbuy/public/uploads/2014/11/1/dep-bong-mang-trong-nha (3).jpg";i:1;s:80:"http://localhost/bidbuy/public/uploads/2014/11/1/dep-bong-mang-trong-nha (5).jpg";i:2;s:81:"http://localhost/bidbuy/public/uploads/2014/11/1/dep-bong-mang-trong-nha (15).jpg";}'),
(30967, 1857, 'product_end_date', '2014/11/01 12:48:47'),
(30968, 1858, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/cm_b35672.jpg'),
(30969, 1858, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635473486290013467.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635473486392661647.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635473486746002268.jpg";}'),
(30970, 1858, 'product_sku', 'AAA110'),
(30971, 1858, 'product_price', '89000'),
(30972, 1858, 'product_price_step', '200000'),
(30973, 1858, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:1:"1";}'),
(30974, 1858, 'product_top_bid', '0'),
(30975, 1858, 'product_end_date', '2014/11/01 10:51:37'),
(30976, 1859, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/cm_b6588.jpg'),
(30977, 1859, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/1635240236934731148.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635240237653112410.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635240236932859145.jpg";}'),
(30978, 1859, 'product_sku', 'SN0011'),
(30979, 1859, 'product_price', '649000'),
(30980, 1859, 'product_price_step', '200000'),
(30981, 1859, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:1:"1";}'),
(30982, 1859, 'product_top_bid', '0'),
(30983, 1859, 'product_end_date', '2014/11/01 11:13:10'),
(30984, 1860, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/cm_b37267.jpg'),
(30985, 1860, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/2635501960797767299.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/1635501960795739295.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635501960793711291.jpg";}'),
(30986, 1860, 'product_sku', 'AT110'),
(30987, 1860, 'product_price', '129000'),
(30988, 1860, 'product_price_step', '200000'),
(30989, 1860, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:1:"1";}'),
(30990, 1860, 'product_top_bid', '0'),
(30991, 1860, 'product_end_date', '2014/11/01 11:35:34'),
(30992, 1850, 'product_end_date', '2014/11/07 00:06:02'),
(30993, 1852, 'product_end_date', '2014/11/04 00:50:31'),
(30994, 1851, 'product_end_date', '2014/11/03 00:18:34'),
(30995, 1861, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/cm_b38357.jpg'),
(30996, 1861, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635502568211822165.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635502568318838353.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635502568419146529.jpg";}'),
(30997, 1861, 'product_sku', 'VA991'),
(30998, 1861, 'product_price', '99000'),
(30999, 1861, 'product_price_step', '200000'),
(31000, 1861, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:2:"10";}'),
(31001, 1861, 'product_top_bid', '0'),
(31002, 1862, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/0635501118164430289.jpg'),
(31003, 1862, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635501733377915857.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/1635501118167706295.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/2635501118170202299.jpg";}'),
(31004, 1862, 'product_sku', 'TE0011'),
(31005, 1862, 'product_price', '35000'),
(31006, 1862, 'product_price_step', '200000'),
(31007, 1862, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:1:"5";}'),
(31008, 1862, 'product_top_bid', '0'),
(31009, 1863, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/cm_b37480.jpg'),
(31010, 1863, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635492278178023674.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635492278616072443.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635492278654448511.jpg";}'),
(31011, 1863, 'product_sku', 'Q00119'),
(31012, 1863, 'product_price', '179000'),
(31013, 1863, 'product_price_step', '200000'),
(31014, 1863, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:1:"5";}'),
(31015, 1863, 'product_top_bid', '0'),
(31016, 1864, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/cm_b37480.jpg'),
(31017, 1864, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635492278178023674.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635492278616072443.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635492278654448511.jpg";}'),
(31018, 1864, 'product_sku', 'Q00119'),
(31019, 1864, 'product_price', '179000'),
(31020, 1864, 'product_price_step', '200000'),
(31021, 1864, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:1:"5";}'),
(31022, 1864, 'product_top_bid', '0'),
(31023, 1861, 'product_end_date', '2014/11/01 12:39:41'),
(31024, 1865, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/0635494800872338552.jpg'),
(31025, 1865, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/1635494800873742555.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/2635494800876238559.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/3635494800878422563.jpg";}'),
(31026, 1865, 'product_sku', 'B001'),
(31027, 1865, 'product_price', '895000'),
(31028, 1865, 'product_price_step', '200000'),
(31029, 1865, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:1:"1";}'),
(31030, 1865, 'product_top_bid', '0'),
(31031, 1866, 'feature_img', 'http://localhost/bidbuy/public/uploads/2014/11/1/2635468081064911691.jpg'),
(31032, 1866, 'product_gallery', 'a:3:{i:0;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635468081061479685.jpg";i:1;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/0635473180555528473.jpg";i:2;s:72:"http://localhost/bidbuy/public/uploads/2014/11/1/1635468081063195688.jpg";}'),
(31033, 1866, 'product_sku', 'KS110'),
(31034, 1866, 'product_price', '250000'),
(31035, 1866, 'product_price_step', '200000'),
(31036, 1866, 'product_timeout', 'a:3:{i:0;s:1:"0";i:1;s:1:"0";i:2;s:1:"5";}'),
(31037, 1866, 'product_top_bid', '0'),
(31038, 1865, 'product_end_date', '2014/11/01 16:17:38');

-- --------------------------------------------------------

--
-- Table structure for table `bbv_posts`
--

CREATE TABLE IF NOT EXISTS `bbv_posts` (
`ID` bigint(20) unsigned NOT NULL,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1867 ;

--
-- Dumping data for table `bbv_posts`
--

INSERT INTO `bbv_posts` (`ID`, `post_author`, `post_date`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_content_filtered`, `post_parent`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1847, 1, '2014-10-31 08:57:21', '&lt;p class=&quot;deal_detail_name_long&quot;&gt;&lt;span style=&quot;font-size: 14pt;&quot;&gt;Bộ drap giường cotton cao cấp Senky v&amp;agrave; Vikomat (1m6 x 2m) bao gồm 1 drap giường v&amp;agrave; 2 &amp;aacute;o gối với họa tiết đẹp mắt, chất liệu mềm mại mang đến cho bạn v&amp;agrave; người th&amp;acirc;n những đ&amp;ecirc;m ngon giấc. Chỉ 160.000đ cho trị gi&amp;aacute; 320.000đ&lt;/span&gt;&lt;/p&gt;', 'Bộ drap giường cotton cao cấp Senky và Vikomat (1m6 x 2m)', '', 'on-process', 'open', 'open', '', 'bo-drap-giuong-cotton-cao-cap-senky-va-vikomat-1m6-x-2m', '', '', '2014-10-31 08:57:21', '', 0, 0, 'product', '', 0),
(1848, 1, '2014-10-31 09:10:37', '&lt;h2 class=&quot;deal_detail_name_long&quot;&gt;Set quần v&amp;aacute;y form d&amp;agrave;i v&amp;agrave; &amp;aacute;o tay d&amp;agrave;i họa tiết h&amp;igrave;nh m&amp;egrave;o ngộ nghĩnh l&amp;agrave;m từ chất liệu thun cotton tho&amp;aacute;ng m&amp;aacute;t, vừa gi&amp;uacute;p b&amp;eacute; thoải m&amp;aacute;i vui chơi vừa đem đến n&amp;eacute;t đ&amp;aacute;ng y&amp;ecirc;u, trẻ trung cho b&amp;eacute;. Chỉ 125.000đ cho trị gi&amp;aacute; 250.000đ.&lt;/h2&gt;&lt;h4 class=&quot;title&quot;&gt;Chi tiết khuyến m&amp;atilde;i&lt;/h4&gt;&lt;div id=&quot;description&quot; class=&quot;deal_content&quot;&gt;&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;Set quần v&amp;aacute;y v&amp;agrave; &amp;aacute;o tay d&amp;agrave;i họa tiết cho b&amp;eacute;&lt;/strong&gt; được&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&amp;nbsp;thiết kế xinh xắn mang đến vẻ đ&amp;aacute;ng y&amp;ecirc;u, dễ thương cho c&amp;aacute;c b&amp;eacute; g&amp;aacute;i khi b&amp;eacute; dạo chơi c&amp;ugrave;ng ba mẹ.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%281%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;415&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;em&gt;&lt;span style=&quot;font-size: small;&quot;&gt;H&amp;igrave;nh minh họa&lt;/span&gt;&lt;/em&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%282%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;766&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;em&gt;&lt;span style=&quot;font-size: small;&quot;&gt;H&amp;igrave;nh minh họa&lt;/span&gt;&lt;/em&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%283%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;440&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;em&gt;&lt;span style=&quot;font-size: small;&quot;&gt;H&amp;igrave;nh minh họa&lt;/span&gt;&lt;/em&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%284%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;1012&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;em&gt;&lt;span style=&quot;font-size: small;&quot;&gt;H&amp;igrave;nh sản phẩm thật&lt;/span&gt;&lt;/em&gt;&lt;/p&gt;&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Set trang phục gồm &amp;aacute;o thun v&amp;agrave; quần v&amp;aacute;y kết hợp độc đ&amp;aacute;o. &amp;Aacute;o cổ tr&amp;ograve;n, tay d&amp;agrave;i in họa tiết h&amp;igrave;nh m&amp;egrave;o ngộ nghĩnh cho b&amp;eacute; th&amp;ecirc;m nổi bật, trẻ trung.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%285%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;650&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%286%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;650&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Quần v&amp;aacute;y với form d&amp;agrave;i &amp;ocirc;m nhẹ cơ thể, lưng thun co gi&amp;atilde;n tốt cho b&amp;eacute; thoải m&amp;aacute;i vận động, vui đ&amp;ugrave;a.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%287%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;684&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chất liệu thun cotton mềm mại, tho&amp;aacute;ng m&amp;aacute;t, &amp;ecirc;m dịu với l&amp;agrave;n da đem lại cảm gi&amp;aacute;c dễ chịu cho b&amp;eacute; khi mặc.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%288%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;650&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Sản phẩm c&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&amp;oacute; 3 m&amp;agrave;u hồng, đỏ, xanh v&amp;agrave; nhiều size để cha mẹ lựa chọn ph&amp;ugrave; hợp với độ tuổi của b&amp;eacute; (từ 2 - 7 tuổi).&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%289%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;998&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%2810%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;1012&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38365/set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be%20%2811%29.jpg&quot; alt=&quot;set quan vay va ao tay dai hoa tiet cho be&quot; width=&quot;650&quot; height=&quot;458&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;/div&gt;', 'Set quần váy và áo tay dài họa tiết cho bé (từ 2 - 7 tuổi)', '', 'timeout', 'open', 'open', '', 'set-quan-vay-va-ao-tay-dai-hoa-tiet-cho-be-tu-2-7-tuoi', '', '', '2014-10-31 09:10:37', '', 0, 0, 'product', '', 0),
(1849, 1, '2014-10-31 09:14:38', '&lt;h2 class=&quot;deal_detail_name_long&quot;&gt;Đầm nữ với kiểu d&amp;aacute;ng trẻ trung, thiết kế form d&amp;aacute;ng x&amp;ograve;e, cổ tr&amp;ograve;n c&amp;oacute; b&amp;acirc;u c&amp;aacute;ch điệu, tay lỡ kết hợp cắt lazer phần ch&amp;acirc;n v&amp;aacute;y mang đến cho bạn g&amp;aacute;i n&amp;eacute;t dịu d&amp;agrave;ng, quyến rũ. Chỉ 189.000đ cho trị gi&amp;aacute; 378.000đ.&lt;/h2&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;em&gt;&lt;strong&gt;Đầm cắt lazer Hana&lt;/strong&gt;&lt;/em&gt;&amp;nbsp;với kiểu d&amp;aacute;ng trẻ trung mang đến cho bạn g&amp;aacute;i n&amp;eacute;t dịu d&amp;agrave;ng, quyến rũ. &lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai dam cat lazer gia re&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38552/dam-cat-lazer%20%281%29.jpg&quot; alt=&quot;khuyen mai dam cat lazer gia re&quot; width=&quot;650px&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;em&gt;Ảnh minh họa&lt;/em&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai dam cat lazer gia re&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38552/dam-cat-lazer%20%282%29.jpg&quot; alt=&quot;khuyen mai dam cat lazer gia re&quot; width=&quot;650px&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai dam cat lazer gia re&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38552/dam-cat-lazer%20%284%29.jpg&quot; alt=&quot;khuyen mai dam cat lazer gia re&quot; width=&quot;650px&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai dam cat lazer gia re&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38552/dam-cat-lazer%20%283%29.jpg&quot; alt=&quot;khuyen mai dam cat lazer gia re&quot; width=&quot;650px&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai dam cat lazer gia re&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38552/dam-cat-lazer%20%285%29.jpg&quot; alt=&quot;khuyen mai dam cat lazer gia re&quot; width=&quot;650px&quot; /&gt;&lt;/span&gt;&lt;/p&gt;', 'Đầm cắt lazer Hana', '', 'on-process', 'open', 'open', '', 'dam-cat-lazer-hana', '', '', '2014-10-31 09:14:38', '', 0, 0, 'product', '', 0),
(1850, 1, '2014-10-31 09:17:20', '&lt;h2 class=&quot;deal_detail_name_long&quot;&gt;Bộ dụng cụ cắt tỉa rau quả 10 m&amp;oacute;n Nicer Dicer bao gồm đầy đủ c&amp;aacute;c c&amp;ocirc;ng cụ như b&amp;agrave;o, cắt hạt lựu, cắt chia 4, chia 8... cho bạn thoải m&amp;aacute;i lựa chọn để gi&amp;uacute;p việc nội trợ của bạn nhẹ nh&amp;agrave;ng hơn. Chỉ 215.000đ cho trị gi&amp;aacute; 390.000đ.&lt;/h2&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;h4 class=&quot;title&quot;&gt;Chi tiết khuyến m&amp;atilde;i&lt;/h4&gt;&lt;div id=&quot;description&quot; class=&quot;deal_content&quot;&gt;&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;em&gt;Dụng cụ cắt rau củ quả 10 m&amp;oacute;n&lt;/em&gt; Nicer Dicer l&amp;agrave; sản phẩm c&amp;oacute; k&amp;iacute;ch thước gọn nhẹ nhưng kết hợp những chức năng tiện &amp;iacute;ch trong c&amp;ugrave;ng một bộ sản phẩm sẽ la một m&amp;oacute;n qu&amp;agrave; cực kỳ &amp;yacute; nghĩa d&amp;agrave;nh tặng cho c&amp;aacute;c b&amp;agrave; nội trợ.&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; src=&quot;http://resources.cungmua.com/ftpproduct/19337/nhom-mua-chung-hot-deal-bo-dung-cu-cat-tia-rau-qua-10-mon-nicer-dicer-gia-re-tai-cung-mua%20%282%29.jpg&quot; alt=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; width=&quot;650&quot; height=&quot;454&quot; /&gt;&lt;br /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; src=&quot;http://resources.cungmua.com/ftpproduct/19337/nhom-mua-chung-hot-deal-bo-dung-cu-cat-tia-rau-qua-10-mon-nicer-dicer-gia-re-tai-cung-mua%20%2810%29.jpg&quot; alt=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; width=&quot;650&quot; height=&quot;436&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img title=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; src=&quot;http://resources.cungmua.com/ftpproduct/19337/nhom-mua-chung-hot-deal-bo-dung-cu-cat-tia-rau-qua-10-mon-nicer-dicer-gia-re-tai-cung-mua%20%283%29.jpg&quot; alt=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; width=&quot;650&quot; height=&quot;493&quot; /&gt;&lt;/p&gt;&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Bộ &lt;em&gt;dụng cụ cắt rau củ quả 10 m&amp;oacute;n&lt;/em&gt; Nicer Dicer bao gồm 5 dụng cụ cắt th&amp;aacute;i đa năng (c&amp;oacute; c&amp;aacute;c lưỡi cắt để bạn lựa chọn kiểu cắt). C&amp;aacute;c dụng cụ th&amp;aacute;i với lưỡi cắt chất liệu inox bền chắc (c&amp;oacute; hoặc kh&amp;ocirc;ng c&amp;oacute; răng cưa) cho l&amp;aacute;t cắt sắc b&amp;eacute;n với th&amp;agrave;nh phẩm mang nhiều h&amp;igrave;nh th&amp;ugrave; kh&amp;aacute;c nhau. C&amp;aacute;c dụng cụ cắt th&amp;aacute;i n&amp;agrave;y khi sử dụng được gắn v&amp;agrave;o một b&amp;agrave;n th&amp;aacute;i, đặt l&amp;ecirc;n hộp đựng... bạn sẽ dễ d&amp;agrave;ng thao t&amp;aacute;c một c&amp;aacute;ch nhanh ch&amp;oacute;ng v&amp;agrave; gọn nhẹ, cho ra th&amp;agrave;nh phẩm đẹp mắt v&amp;agrave; vệ sinh.&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; src=&quot;http://resources.cungmua.com/ftpproduct/19337/nhom-mua-chung-hot-deal-bo-dung-cu-cat-tia-rau-qua-10-mon-nicer-dicer-gia-re-tai-cung-mua%20%284%29.jpg&quot; alt=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; width=&quot;650&quot; height=&quot;385&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; src=&quot;http://resources.cungmua.com/ftpproduct/19337/nhom-mua-chung-hot-deal-bo-dung-cu-cat-tia-rau-qua-10-mon-nicer-dicer-gia-re-tai-cung-mua%20%285%29.jpg&quot; alt=&quot;khuyen mai gia re dung cu cat tia rau qua 10 mon nicer dicer&quot; width=&quot;650&quot; height=&quot;488&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Ngo&amp;agrave;i c&amp;aacute;c dụng cụ cắt th&amp;aacute;i, bộ sản phẩm c&amp;ograve;n c&amp;oacute; dụng cụ gọt hoa quả, hay chức năng m&amp;agrave;i c&amp;aacute;c loại củ v&amp;agrave; cắt th&amp;agrave;nh những miếng rau củ c&amp;oacute; dạng lưới rất nhanh v&amp;agrave; đẹp mắt. Thay v&amp;igrave; phải huy động một l&amp;uacute;c cả đống dao: dao gọt vỏ, dao b&amp;agrave;o sợi, dao nhọn để cắt tỉa &amp;hellip;để cắt tỉa th&amp;igrave; giờ đ&amp;acirc;y, bạn chỉ cần bộ dụng cụ nhỏ gọn, tiện dụng m&amp;agrave; lại rất dễ d&amp;ugrave;ng n&amp;agrave;y!&lt;/span&gt;&lt;/p&gt;&lt;/div&gt;', 'Bộ dụng cụ cắt tỉa rau quả 10 món Nicer Dicer', '', 'on-process', 'open', 'open', '', 'bo-dung-cu-cat-tia-rau-qua-10-mon-nicer-dicer', '', '', '2014-10-31 09:17:20', '', 0, 0, 'product', '', 0),
(1851, 1, '2014-10-31 09:22:05', '&lt;p class=&quot;deal_detail_name_long&quot;&gt;&lt;span style=&quot;font-size: 14pt;&quot;&gt;Với thiết kế tiện dụng, kiểu d&amp;aacute;ng nhỏ gọn combo 5 t&amp;uacute;i x&amp;aacute;ch cho mẹ v&amp;agrave; b&amp;eacute; gi&amp;uacute;p bạn đựng được nhiều vật dụng của b&amp;eacute; khi đi chơi xa một c&amp;aacute;ch gọn g&amp;agrave;ng m&amp;agrave; kh&amp;ocirc;ng lo bị thất lạc. Chỉ 299.000đ cho trị gi&amp;aacute; 598.000đ.&lt;/span&gt;&lt;/p&gt;&lt;p class=&quot;deal_detail_name_long&quot;&gt;&amp;nbsp;&lt;/p&gt;&lt;h4 class=&quot;title&quot;&gt;Chi tiết khuyến m&amp;atilde;i&lt;/h4&gt;&lt;p class=&quot;deal_detail_name_long&quot;&gt;&amp;nbsp;&lt;/p&gt;&lt;div id=&quot;description&quot; class=&quot;deal_content&quot;&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;&lt;em&gt;Combo 5 t&amp;uacute;i x&amp;aacute;ch cho mẹ v&amp;agrave; b&amp;eacute; &lt;/em&gt;&lt;/strong&gt;l&amp;agrave; sản phẩm tiện dụng gi&amp;uacute;p bạn đựng được nhiều vật dụng của b&amp;eacute; một c&amp;aacute;ch gọn g&amp;agrave;ng khi đi chơi xa m&amp;agrave; kh&amp;ocirc;ng lo bị thất lạc. &lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;khuyen mai combo 5 tui x&amp;aacute;ch cho me va be gia re&quot; src=&quot;http://resources.cungmua.com/FTPProduct/34866/combo-5-tui-x%C3%A1ch-cho-me-va-be%20%281%29.jpg&quot; alt=&quot;khuyen mai combo 5 tui x&amp;aacute;ch cho me va be gia re&quot; width=&quot;650px&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-size: small; text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Sản phẩm gồm: 1&amp;nbsp;t&amp;uacute;i to đựng bỉm, quần &amp;aacute;o cho b&amp;eacute;; 1 t&amp;uacute;i nhỏ đựng khăn, c&amp;aacute;c vật dụng nhỏ cần thiết; 1 tấm l&amp;oacute;t tiện dụng chống thấm 2 mặt; 1 t&amp;uacute;i đựng b&amp;igrave;nh sữa; 1 t&amp;uacute;i đựng thức ăn.&lt;/span&gt;&lt;/p&gt;&lt;/div&gt;&lt;p class=&quot;deal_detail_name_long&quot;&gt;&amp;nbsp;&lt;/p&gt;', 'Combo 5 túi xách cho mẹ và bé', '', 'on-process', 'open', 'open', '', 'combo-5-tui-xach-cho-me-va-be', '', '', '2014-10-31 09:22:05', '', 0, 0, 'product', '', 0),
(1852, 1, '2014-10-31 09:25:18', '&lt;h2 class=&quot;deal_detail_name_long&quot;&gt;Pin sạc dự ph&amp;ograve;ng Romoss với kiểu d&amp;aacute;ng gọn nhẹ c&amp;ugrave;ng dung lượng cực lớn 20.000mAh sẽ gi&amp;uacute;p cho bạn thoải m&amp;aacute;i sử dụng điện thoại của m&amp;igrave;nh m&amp;agrave; kh&amp;ocirc;ng phải lo hết pin. Chỉ 350.000đ cho trị gi&amp;aacute; 700.000đ.&lt;/h2&gt;&lt;h4 class=&quot;title&quot;&gt;Chi tiết khuyến m&amp;atilde;i&lt;/h4&gt;&lt;div id=&quot;description&quot; class=&quot;deal_content&quot;&gt;&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;em&gt;Pin sạc dự ph&amp;ograve;ng Romoss 20.000mAh&lt;/em&gt; đa năng được sản xuất theo c&amp;ocirc;ng nghệ lưu trữ chất lượng cao mang đến sự h&amp;agrave;i l&amp;ograve;ng cho kh&amp;aacute;ch h&amp;agrave;ng. Đ&amp;acirc;y l&amp;agrave; sản phẩm tiện &amp;iacute;ch th&amp;iacute;ch hợp sử dụng với người thường xuy&amp;ecirc;n phải di chuyển, c&amp;aacute;c bạn trẻ th&amp;iacute;ch đi du lịch khi kh&amp;ocirc;ng c&amp;oacute; nguồn điện gần b&amp;ecirc;n.&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img title=&quot;KHUYEN MAI PIN SAC DU PHONG ROMOSS 20000MAH DA NANG GIA RE&quot; src=&quot;http://resources.cungmua.com/FTPProduct/38188/pin-sac-du-phong-romoss-20000mah-da-nang%20%281%29.jpg&quot; alt=&quot;KHUYEN MAI PIN SAC DU PHONG ROMOSS 20000MAH DA NANG GIA RE&quot; width=&quot;650px&quot; /&gt;&lt;/span&gt;&lt;/p&gt;&lt;/div&gt;', 'Pin sạc dự phòng Romoss 20.000mAh chính hãng - BH 12 tháng', '', 'on-process', 'open', 'open', '', 'pin-sac-du-phong-romoss-20-000mah-chinh-hang-bh-12-thang', '', '', '2014-10-31 09:25:18', '', 0, 0, 'product', '', 0),
(1853, 1, '2014-10-31 09:27:34', '&lt;h2 class=&quot;deal_detail_name_long&quot;&gt;Bộ drap MIX COLOR cao cấp c&amp;oacute; bọc mền kiểu H&amp;agrave;n Quốc - Mẫu m&amp;atilde; m&amp;agrave;u sắc tươi tắn gi&amp;uacute;p cho kh&amp;ocirc;ng gian ph&amp;ograve;ng ngủ của bạn trở n&amp;ecirc;n đẹp mắt, chất liệu mềm mại g&amp;oacute;p phần mang lại giấc ngủ s&amp;acirc;u v&amp;agrave; ngon cho người sử dụng. Chỉ 395.000đ cho trị gi&amp;aacute; 789.000đ.&lt;/h2&gt;&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul style=&quot;text-align: justify;&quot;&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;Bộ drap MIX COLOR cao cấp c&amp;oacute; bọc mền kiểu H&amp;agrave;n Quốc&lt;/strong&gt;&lt;/span&gt;&amp;nbsp;l&amp;agrave; sự lựa chọn ho&amp;agrave;n hảo mang đến giấc ngủ nhẹ nh&amp;agrave;ng, thư th&amp;aacute;i cho cả gia đ&amp;igrave;nh bạn.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Sản phẩm được may từ chất liệu cotton mềm mại cao cấp, mềm mịn tạo sự thoải m&amp;aacute;i, &amp;ecirc;m dịu cho người d&amp;ugrave;ng, kh&amp;ocirc;ng lo x&amp;ugrave; l&amp;ocirc;ng, phai m&amp;agrave;u sau thời gian sử dụng. Kh&amp;ocirc;ng phai m&amp;agrave;u, kh&amp;ocirc;ng bụi vải, kh&amp;ocirc;ng nho&amp;egrave; hoạ tiết.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;C&amp;aacute;c họa tiết hoa văn đẹp mắt, trẻ trung, tươi s&amp;aacute;ng gi&amp;uacute;p điểm t&amp;ocirc; cho căn ph&amp;ograve;ng ngủ th&amp;ecirc;m sang trọng, m&amp;agrave;u sắc.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;M&amp;agrave;u sắc: t&amp;iacute;m - hồng, t&amp;iacute;m - xanh, xanh - xanh l&amp;aacute;, xanh - xanh x&amp;aacute;m, hồng - x&amp;aacute;m.&lt;br /&gt;&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;K&amp;iacute;ch thước (cm): drap (bo g&amp;oacute;c) 160 x 200 x 20 - 2 gối ngủ 50 x 70 - 1 bọc mền 180 x 200.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Xuất xứ: Việt Nam.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;', 'Bộ drap MIX COLOR cao cấp có bọc mền kiểu Hàn Quốc', '', 'trash', 'open', 'open', '', 'bo-drap-mix-color-cao-cap-co-boc-men-kieu-han-quoc', '', '', '2014-10-31 09:27:34', '', 0, 0, 'product', '', 0),
(1854, 1, '2014-11-01 12:09:08', '&lt;h2 class=&quot;deal_detail_name_long&quot;&gt;H&amp;atilde;y d&amp;agrave;nh tặng cho người th&amp;acirc;n, bạn b&amp;egrave; m&amp;oacute;n qu&amp;agrave; ngọt ng&amp;agrave;o đến từ những chiếc b&amp;aacute;nh su kem Singapore Chewy Junior thơm ngon độc đ&amp;aacute;o với gi&amp;aacute; ưu đ&amp;atilde;i mừng sinh nhật lần 5 của hệ thống Chewy Junior tại Việt Nam. Chỉ 69.000đ cho trị gi&amp;aacute; 100.000đ.&lt;/h2&gt;&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;B&amp;aacute;nh su kem Singapore Chewy Junior&lt;/strong&gt; l&amp;agrave; một thương hiệu b&amp;aacute;nh do &amp;ocirc;ng Kevin Ong - người c&amp;oacute; hơn 20 năm kinh nghiệm trong ng&amp;agrave;nh thực phẩm s&amp;aacute;ng tạo ra dựa tr&amp;ecirc;n sự kết hợp giữa 2 loại b&amp;aacute;nh từ Nhật Bản v&amp;agrave; Mexico.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;Chewy Junior&lt;/strong&gt; l&amp;agrave; d&amp;ograve;ng sản phẩm chuy&amp;ecirc;n về b&amp;aacute;nh su nh&amp;acirc;n kem tươi, b&amp;ecirc;n ngo&amp;agrave;i b&amp;aacute;nh được bao phủ bằng c&amp;aacute;c loại mứt, hạt trang tr&amp;iacute; được nghi&amp;ecirc;n cứu kỹ lưỡng để c&amp;oacute; thể h&amp;ograve;a hợp với hương vị kem một c&amp;aacute;ch thanh khiết v&amp;agrave; kh&amp;ocirc;ng qu&amp;aacute; ngọt.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Điểm đặc biệt của b&amp;aacute;nh su Chewy Junior l&amp;agrave; được nướng ở nhiệt độ th&amp;iacute;ch hợp với c&amp;ocirc;ng thức bột độc đ&amp;aacute;o, khiến b&amp;aacute;nh dẻo khi ăn n&amp;oacute;ng v&amp;agrave; dai khi ăn lạnh, c&amp;ugrave;ng với c&amp;aacute;c loại nh&amp;acirc;n kem tươi phong ph&amp;uacute; tạo n&amp;ecirc;n một thương hiệu b&amp;aacute;nh nh&amp;acirc;n kem tuyệt vời.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;100% b&amp;aacute;nh được nướng v&amp;agrave; b&amp;aacute;n trong ng&amp;agrave;y.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Thực đơn c&amp;aacute;c loại b&amp;aacute;nh phong ph&amp;uacute;, gần 40 loại b&amp;aacute;nh với hương vị thơm ngon kh&amp;aacute;c nhau cho bạn thoải m&amp;aacute;i chọn lựa.&amp;nbsp;&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kh&amp;ocirc;ng gian cửa h&amp;agrave;ng m&amp;aacute;t mẻ, rộng r&amp;atilde;i, thiết kế trẻ trung. Đội ngũ nh&amp;acirc;n vi&amp;ecirc;n phục vụ chu đ&amp;aacute;o, nhiệt t&amp;igrave;nh.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Thực đơn tham khảo tại &lt;a href=&quot;http://www.chewyjunior.com.vn/&quot; target=&quot;_blank&quot; rel=&quot;nofollow&quot;&gt;www.chewyjunior.com.vn&lt;/a&gt;&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;&lt;/div&gt;&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Lưu &amp;yacute; khi mua&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size: small;&quot;&gt;VOUCHER TRỊ GI&amp;Aacute; 100.000Đ&lt;/span&gt;&lt;/strong&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&amp;Aacute;p dụng cho tất cả c&amp;aacute;c loại b&amp;aacute;nh c&amp;oacute; trong menu tại Chewy Junior (Trừ b&amp;aacute;nh sinh nhật v&amp;agrave; sự kiện).&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Thời gian: 09h &amp;ndash; 22h hằng ng&amp;agrave;y (Kh&amp;ocirc;ng &amp;aacute;p dụng cho ng&amp;agrave;y Lễ 20/10, 20/11, 24 - 25/12/2014).&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Hạn sử dụng voucher: từ 06/10/2014 - 31/12/2014.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Một kh&amp;aacute;ch h&amp;agrave;ng c&amp;oacute; thể mua nhiều voucher để sử dụng.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kh&amp;aacute;ch h&amp;agrave;ng đăng k&amp;yacute; mua tối thiểu 2 voucher.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Nếu c&amp;oacute; bất kỳ ph&amp;agrave;n n&amp;agrave;n hoặc khiếu nại về dịch vụ/ sản phẩm vui l&amp;ograve;ng li&amp;ecirc;n hệ Hotline: (08) 3505 8053.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kh&amp;aacute;ch h&amp;agrave;ng vui l&amp;ograve;ng li&amp;ecirc;n hệ đặt b&amp;aacute;nh trước khi đến theo số điện thoại c&amp;aacute;c cửa h&amp;agrave;ng.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Giao h&amp;agrave;ng miễn ph&amp;iacute; từ 3 voucher trở l&amp;ecirc;n&amp;nbsp;(Trừ khu vực Q. 9, Q. 12, Q. G&amp;ograve; Vấp, Q. Thủ Đức, Q. B&amp;igrave;nh Ch&amp;aacute;nh, Q. B&amp;igrave;nh T&amp;acirc;n, Q. T&amp;acirc;n Ph&amp;uacute;, Q.6 khu vực gi&amp;aacute;p Long An).&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chewy Junior -&amp;nbsp;447 Nguyễn Tri Phương, Q. 10:&amp;nbsp;Kh&amp;ocirc;ng nhận giao h&amp;agrave;ng ở khu vực Q. 8, Q. T&amp;acirc;n Ph&amp;uacute;, Q. 9, Q. 12, Q. G&amp;ograve; Vấp, Q. Thủ Đức, Q. B&amp;igrave;nh Ch&amp;aacute;nh, Q. B&amp;igrave;nh T&amp;acirc;n, Q.6 khu vực gi&amp;aacute;p Long An.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chewy Junior -&amp;nbsp;99 Trần N&amp;atilde;o, Q. 2:&amp;nbsp;Chỉ nhận giao h&amp;agrave;ng trong phạm vi b&amp;aacute;n k&amp;iacute;nh 7 km.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chewy Junior - Số 3 Mậu Th&amp;acirc;n, P. Xu&amp;acirc;n Kh&amp;aacute;nh, Q. Ninh Kiều, TP. Cần Thơ: &amp;Aacute;p dụng giao h&amp;agrave;ng từ 2 voucher trở l&amp;ecirc;n.&amp;nbsp;&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kh&amp;ocirc;ng quy đổi th&amp;agrave;nh tiền. Kh&amp;ocirc;ng &amp;aacute;p dụng cho c&amp;aacute;c khuyến m&amp;atilde;i kh&amp;aacute;c.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Voucher c&amp;ograve;n hạn sử dụng sẽ được trả v&amp;igrave; bất kỳ l&amp;yacute; do g&amp;igrave;.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;&lt;/div&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;', 'Mừng sinh nhật lần 5 Chewy Junior - Bánh su Singapore nổi tiếng', '', 'trash', 'open', 'open', '', 'mung-sinh-nhat-lan-5-chewy-junior-banh-su-singapore-noi-tieng', '', '', '2014-11-01 12:09:08', '', 0, 0, 'product', '', 0),
(1855, 13, '2014-10-31 23:27:21', '&lt;div id=&quot;middle_content&quot; class=&quot;expand&quot; style=&quot;overflow: hidden;&quot;&gt;&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;&lt;em&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Đầm body phong c&amp;aacute;ch Ch&amp;acirc;u &amp;Acirc;u&amp;nbsp;&lt;/span&gt;&lt;/em&gt;&lt;/strong&gt;&lt;span style=&quot;font-size: small;&quot;&gt;mang đến cho ph&amp;aacute;i đẹp n&amp;eacute;t&amp;nbsp;&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;k&amp;iacute;n đ&amp;aacute;o, sang trọng v&amp;agrave; cực quyến rũ.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Thiết kế độc đ&amp;aacute;o, trẻ trung, tỉ mỉ trong từng đường n&amp;eacute;t cho bạn g&amp;aacute;i&amp;nbsp;&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;sự qu&amp;yacute; ph&amp;aacute;i, ki&amp;ecirc;u sa.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kiểu d&amp;aacute;ng xu hướng thời thượng, đầm &amp;ocirc;m body, cổ tr&amp;ograve;n kết hợp tay s&amp;aacute;t c&amp;aacute;nh năng động t&amp;ocirc;n l&amp;ecirc;n d&amp;aacute;ng xinh ngọc ng&amp;agrave; của ph&amp;aacute;i đẹp.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;M&amp;agrave;u sắc trang nh&amp;atilde; kết hợp nh&amp;uacute;n eo tinh tế&amp;nbsp;&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;tạo điểm nhấn nổi bật v&amp;agrave; vẻ thời trang ấn tượng, cuốn h&amp;uacute;t cho bạn g&amp;aacute;i.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Phối c&amp;ugrave;ng c&amp;aacute;c phụ kiện thời trang,&amp;nbsp;&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;th&amp;iacute;ch hợp cho bạn mặc nơi c&amp;ocirc;ng sở, dự tiệc hay trong dịp đi chơi, dạo phố c&amp;ugrave;ng bạn b&amp;egrave;...&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Sản phẩm được may từ chất liệu thun&amp;nbsp;&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;mềm mại, tho&amp;aacute;ng m&amp;aacute;t, đem lại sự dễ chịu v&amp;agrave; vẻ đẹp tự tin cho bạn cử động trong mọi t&amp;igrave;nh huống.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;M&amp;agrave;u sắc: xanh, t&amp;iacute;m.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;K&amp;iacute;ch thước: (cm)&lt;/span&gt;&lt;h4 class=&quot;title&quot;&gt;Chi tiết khuyến m&amp;atilde;i&lt;/h4&gt;&lt;div id=&quot;description&quot; class=&quot;deal_content&quot;&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;&lt;em&gt;Đầm body phong c&amp;aacute;ch Ch&amp;acirc;u &amp;Acirc;u&lt;/em&gt;&lt;/strong&gt;&amp;nbsp;mang đến cho ph&amp;aacute;i đẹp n&amp;eacute;t&amp;nbsp;&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;k&amp;iacute;n đ&amp;aacute;o, sang trọng v&amp;agrave; cực quyến rũ.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;img style=&quot;display: block; margin-left: auto; margin-right: auto;&quot; title=&quot;khuyen mai dam body gia re&quot; src=&quot;http://resources.cungmua.com/FTPProduct/37312/dam-body%20%282%29.jpg&quot; alt=&quot;khuyen mai dam body gia re&quot; width=&quot;650px&quot; /&gt;&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Thiết kế độc đ&amp;aacute;o, trẻ trung, tỉ mỉ trong từng đường n&amp;eacute;t cho bạn g&amp;aacute;i&amp;nbsp;&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;sự qu&amp;yacute; ph&amp;aacute;i, ki&amp;ecirc;u sa.&lt;/span&gt;&lt;/p&gt;&lt;/div&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;&lt;/div&gt;&lt;/div&gt;', 'Đầm body phong cách Châu Âu', '', 'on-process', 'open', 'open', '', 'dam-body-phong-cach-chau-au', '', '', '2014-10-31 23:27:21', '', 0, 0, 'product', '', 0),
(1856, 1, '2014-11-01 10:39:02', '&lt;div id=&quot;middle_content_wrapper&quot; class=&quot;expand&quot;&gt;&lt;div id=&quot;middle_content&quot; class=&quot;expand&quot; style=&quot;overflow: hidden;&quot;&gt;&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;Đồng hồ nữ cờ Anh đ&amp;iacute;nh hạt sang trọng&lt;/strong&gt; thiết kế thời trang, kiểu d&amp;aacute;ng gọn nhẹ, gi&amp;uacute;p bạn g&amp;aacute;i quản l&amp;yacute; giờ giấc hiệu quả v&amp;agrave; đem đến phong c&amp;aacute;ch c&amp;aacute; t&amp;iacute;nh.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kiểu d&amp;aacute;ng trẻ trung, mặt kiếng tr&amp;ograve;n họa tiết cờ Anh kết hợp đ&amp;iacute;nh đ&amp;aacute; viền xung quanh tạo độ s&amp;aacute;ng lấp l&amp;aacute;nh, sang trọng.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;D&amp;acirc;y đeo dạng nấc g&amp;agrave;i tiện lợi sử dụng, c&amp;oacute; thể mix c&amp;ugrave;ng c&amp;aacute;c kiểu trang phục kh&amp;aacute;c nhau tạo phong c&amp;aacute;ch s&amp;agrave;nh điệu.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;L&amp;agrave; m&amp;oacute;n phụ kiện kh&amp;ocirc;ng thể thiếu trong việc học tập, c&amp;ocirc;ng việc của ph&amp;aacute;i đẹp.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chất liệu simili giả da bền đẹp, sử dụng được trong thời gian l&amp;acirc;u d&amp;agrave;i.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;M&amp;agrave;u sắc: trắng, đen, n&amp;acirc;u, đỏ, hồng.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/div&gt;&lt;/div&gt;&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Lưu &amp;yacute; khi mua&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chỉ 99.000đ c&amp;oacute; ngay &lt;strong&gt;01&amp;nbsp;Đồng hồ nữ cờ Anh đ&amp;iacute;nh hạt sang trọng&lt;/strong&gt; trị gi&amp;aacute; 198.000đ.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Ch&amp;uacute;ng t&amp;ocirc;i giao sản phẩm trực tiếp đến kh&amp;aacute;ch h&amp;agrave;ng.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Được đổi trả trong v&amp;ograve;ng 7 ng&amp;agrave;y.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;&lt;/div&gt;&lt;/div&gt;&lt;/div&gt;', 'Đồng hồ nữ cờ Anh đính hạt sang trọng', '', 'timeout', 'open', 'open', '', 'dong-ho-nu-co-anh-dinh-hat-sang-trong', '', '', '2014-11-01 10:39:02', '', 0, 0, 'product', '', 0),
(1857, 1, '2014-11-01 10:48:44', '&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul style=&quot;text-align: justify;&quot;&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;D&amp;eacute;p b&amp;ocirc;ng đi trong nh&amp;agrave; &lt;/strong&gt;g&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;i&amp;uacute;p bảo vệ đ&amp;ocirc;i ch&amp;acirc;n bạn khỏi bụi bẩn, tr&amp;aacute;nh nứt g&amp;oacute;t.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kiểu d&amp;aacute;ng dễ thương, được thiết kế đơn giản, &amp;ocirc;m trọn b&amp;agrave;n ch&amp;acirc;n một c&amp;aacute;ch nhẹ nh&amp;agrave;ng, thoải m&amp;aacute;i.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;D&amp;eacute;p rất &amp;ecirc;m v&amp;agrave; mềm, đem lại cảm gi&amp;aacute;c thư th&amp;aacute;i v&amp;agrave; an to&amp;agrave;n khi sử dụng.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Th&amp;iacute;ch hợp cho nh&amp;acirc;n vi&amp;ecirc;n văn ph&amp;ograve;ng d&amp;ugrave;ng để đi lại ở c&amp;ocirc;ng ty, hay cho c&amp;aacute;c th&amp;agrave;nh vi&amp;ecirc;n d&amp;ugrave;ng trong gia đ&amp;igrave;nh.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chất liệu mềm mại, nhẹ nh&amp;agrave;ng giữ ấm cho đ&amp;ocirc;i ch&amp;acirc;n bạn.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;K&amp;iacute;ch thước (cm): S (8 x 25cm), M (10 x 28 cm), L (12 x 30cm).&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;&lt;/div&gt;', 'Dép bông đi trong nhà (Việt Nam xuất khẩu)', '', 'timeout', 'open', 'open', '', 'dep-bong-di-trong-nha-viet-nam-xuat-khau', '', '', '2014-11-01 10:48:44', '', 0, 0, 'product', '', 0),
(1858, 1, '2014-11-01 10:50:35', '', 'Giày nữ đính nơ màu đen tặng kèm miếng lót giày - BH 1 tháng', '', 'timeout', 'open', 'open', '', 'giay-nu-dinh-no-mau-den-tang-kem-mieng-lot-giay-bh-1-thang', '', '', '2014-11-01 10:50:35', '', 0, 0, 'product', '', 0),
(1859, 1, '2014-11-01 11:12:03', '&lt;div id=&quot;middle_content&quot; class=&quot;expand&quot; style=&quot;overflow: hidden;&quot;&gt;&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul style=&quot;text-align: justify;&quot;&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;D&amp;acirc;y nịt nam da c&amp;aacute; sấu 100%&lt;/strong&gt; mang đến vẻ lịch l&amp;atilde;m, sang trọng cho ph&amp;aacute;i mạnh.&lt;br /&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chất liệu: l&amp;agrave;m bằng da c&amp;aacute; sấu.&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Thiết kế sang trọng, đẹp mắt, đường may đẹp v&amp;agrave; chắc chắn.&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;K&amp;iacute;ch thước: D&amp;agrave;i 1,2m x Rộng 3,5cm.&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Là quà tặng ý nghĩa cho người th&amp;acirc;n và bạn bè.&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Nếu kh&amp;aacute;ch h&amp;agrave;ng ph&amp;aacute;t hiện kh&amp;ocirc;ng phải da thật, đối t&amp;aacute;c sẽ ho&amp;agrave;n tiền 200% gi&amp;aacute; trị sản phẩm.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;&lt;/div&gt;&lt;/div&gt;', 'Dây nịt nam da cá sấu 100% (BH 24 tháng)', '', 'timeout', 'open', 'open', '', 'day-nit-nam-da-ca-sau-100-bh-24-thang', '', '', '2014-11-01 11:12:03', '', 0, 0, 'product', '', 0),
(1860, 1, '2014-11-01 11:34:18', '&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;em&gt;&lt;strong&gt;&amp;Aacute;o kho&amp;aacute;c nữ phối m&amp;agrave;u&lt;/strong&gt;&lt;/em&gt; chấm bi thiết kế năng động, thời trang mang đến cho bạn g&amp;aacute;i vẻ ngo&amp;agrave;i khỏe khoắn, phong c&amp;aacute;ch.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kiểu d&amp;aacute;ng tay d&amp;agrave;i, form &amp;ocirc;m nhẹ bo dưới c&amp;ugrave;ng mũ rộng gi&amp;uacute;p bạn che bụi, nắng mỗi khi ra ngo&amp;agrave;i.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Điểm nhấn của trang phục l&amp;agrave; phần mũ phối m&amp;agrave;u đẹp mắt, những họa tiết chấm bi ở mũ v&amp;agrave; tay &amp;aacute;o rất&amp;nbsp;trẻ trung.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chất liệu nỉ mềm mại, thấm h&amp;uacute;t mồ h&amp;ocirc;i giữ ấm khi trời trở lạnh m&amp;agrave; vẫn thoải m&amp;aacute;i khi ra ngo&amp;agrave;i l&amp;uacute;c trời nắng.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;M&amp;agrave;u sắc: hồng, v&amp;agrave;ng.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;K&amp;iacute;ch thước (cm):&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;', 'Áo khoác nữ phối màu chấm bi', '', 'timeout', 'open', 'open', '', 'ao-khoac-nu-phoi-mau-cham-bi', '', '', '2014-11-01 11:34:18', '', 0, 0, 'product', '', 0);
INSERT INTO `bbv_posts` (`ID`, `post_author`, `post_date`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_content_filtered`, `post_parent`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1861, 1, '2014-11-01 12:19:51', '&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul style=&quot;text-align: justify;&quot;&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;Đầm x&amp;ograve;e nữ họa tiết phối lưới&lt;/strong&gt;&lt;/span&gt;&amp;nbsp;thiết kế gợi cảm &lt;span style=&quot;font-size: small;&quot;&gt;kiểu đầm x&amp;ograve;e duy&amp;ecirc;n d&amp;aacute;ng, thoải m&amp;aacute;i di chuyển.&lt;/span&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kiều đầm nữ t&amp;iacute;nh với cổ tr&amp;ograve;n, tay con, &amp;ocirc;m eo kh&amp;eacute;o l&amp;eacute;o thật quyến rũ.&lt;br /&gt;&lt;/span&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Điểm nhấn nổi bật với c&amp;aacute;ch phối lưới độc đ&amp;aacute;o kết hợp với họa tiết đẹp mắt.&lt;br /&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chất liệu: &lt;span style=&quot;font-size: small;&quot;&gt;c&amp;aacute;t lụa.&lt;/span&gt;&lt;br /&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;M&amp;agrave;u sắc: v&amp;agrave;ng, xanh, đen.&lt;br /&gt;&lt;/span&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style=&quot;font-size: small;&quot;&gt;K&amp;iacute;ch thước: cm.&lt;br /&gt;&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;table style=&quot;width: 300px;&quot; border=&quot;1&quot; cellspacing=&quot;0&quot; cellpadding=&quot;0&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&amp;nbsp;D&amp;agrave;i&lt;/span&gt;&lt;/td&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Ngực&lt;/span&gt;&lt;/td&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&amp;nbsp; Eo&lt;/span&gt;&lt;/td&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&amp;nbsp;Vai&lt;/span&gt;&lt;/td&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;M&amp;ocirc;ng &lt;/span&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&amp;nbsp;80&lt;/span&gt;&lt;/td&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;70-90&lt;/span&gt;&lt;/td&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;68-84&lt;/span&gt;&lt;/td&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;35&lt;/span&gt;&lt;/td&gt;&lt;td style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&amp;nbsp;&lt;span style=&quot;font-size: small;&quot;&gt;free size &lt;/span&gt;&lt;/span&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;', 'Đầm xòe nữ họa tiết phối lưới gia tot', '', 'timeout', 'open', 'open', '', 'dam-xoe-nu-hoa-tiet-phoi-luoi', '', '', '2014-11-01 12:19:51', '', 0, 0, 'product', '', 0),
(1862, 1, '2014-11-01 12:22:53', '&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;em&gt;&lt;strong&gt;Combo 5 quần chip họa tiết dễ thương cho b&amp;eacute;&lt;/strong&gt;&lt;/em&gt;&amp;nbsp;&lt;/span&gt;&lt;span style=&quot;font-size: small;&quot;&gt;được thiết kế với form d&amp;aacute;ng &amp;ocirc;m mang đến cho b&amp;eacute; y&amp;ecirc;u nh&amp;agrave; bạn cảm gi&amp;aacute;c thật thoải m&amp;aacute;u v&amp;agrave; dễ chịu.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chất liệu thun cotton tho&amp;aacute;ng m&amp;aacute;t, thấm h&amp;uacute;t mồ h&amp;ocirc;i tốt tạo sự dễ chịu gi&amp;uacute;p b&amp;eacute; dễ d&amp;agrave;ng vận động.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Quần nổi bật bởi c&amp;aacute;c họa tiết ngộ nghĩnh, sinh động, m&amp;agrave;u sắc tươi tắn, ph&amp;ugrave; hợp độ tuổi của b&amp;eacute;.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Đường may chắc chắn, tinh tế với lưng thun mềm mại, kh&amp;ocirc;ng in vết hằn l&amp;ecirc;n da b&amp;eacute;.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Th&amp;iacute;ch hợp mặc trong v&amp;aacute;y hay kết hợp c&amp;ugrave;ng c&amp;aacute;c loại &amp;aacute;o thun mỏng, tho&amp;aacute;ng m&amp;aacute;t...&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;', 'Combo 5 quần chip họa tiết dễ thương cho bé', '', 'trash', 'open', 'open', '', 'combo-5-quan-chip-hoa-tiet-de-thuong-cho-be', '', '', '2014-11-01 12:22:53', '', 0, 0, 'product', '', 0),
(1863, 1, '2014-11-01 12:27:45', '&lt;div id=&quot;middle_content&quot; class=&quot;collapse&quot; style=&quot;height: 355px; overflow: hidden;&quot;&gt;&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;Quần kaki nam xuất khẩu cao cấp&lt;/strong&gt; thiết kế thanh lịch mang đến vẻ sang trọng, qu&amp;yacute; phải, thể hiện đẳng cấp cho c&amp;aacute;c bạn nam v&amp;agrave; qu&amp;yacute; &amp;ocirc;ng.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Form quần d&amp;agrave;i &amp;ocirc;m gọn cơ thể, l&amp;agrave;m t&amp;ocirc;n l&amp;ecirc;n đường n&amp;eacute;t mạnh mẽ với lưng quần bản lớn c&amp;oacute; thể phối c&amp;ugrave;ng d&amp;acirc;y nịt tạo phong c&amp;aacute;ch chỉn chu khi đi l&amp;agrave;m.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kiểu phối t&amp;uacute;i 2 b&amp;ecirc;n v&amp;agrave; 2 t&amp;uacute;i ở sau quần tạo điểm nhấn nổi bật, đem lại phong c&amp;aacute;ch năng động, nam t&amp;iacute;nh cho ph&amp;aacute;i mạnh.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chất liệu vải kaki tho&amp;aacute;ng m&amp;aacute;t, tạo cảm gi&amp;aacute;c thoải m&amp;aacute;i khi mặc, cho bạn lu&amp;ocirc;n tự tin trong mọi vận động.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;M&amp;agrave;u sắc: m&amp;agrave;u da, m&amp;agrave;u đen.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;&lt;/div&gt;&lt;/div&gt;', 'Quần kaki nam xuất khẩu cao cấp', '', 'draft', 'open', 'open', '', 'quan-kaki-nam-xuat-khau-cao-cap', '', '', '2014-11-01 12:27:45', '', 0, 0, 'product', '', 0),
(1864, 1, '2014-11-01 12:28:28', '&lt;div id=&quot;middle_content&quot; class=&quot;collapse&quot; style=&quot;height: 355px; overflow: hidden;&quot;&gt;&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;Quần kaki nam xuất khẩu cao cấp&lt;/strong&gt; thiết kế thanh lịch mang đến vẻ sang trọng, qu&amp;yacute; phải, thể hiện đẳng cấp cho c&amp;aacute;c bạn nam v&amp;agrave; qu&amp;yacute; &amp;ocirc;ng.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Form quần d&amp;agrave;i &amp;ocirc;m gọn cơ thể, l&amp;agrave;m t&amp;ocirc;n l&amp;ecirc;n đường n&amp;eacute;t mạnh mẽ với lưng quần bản lớn c&amp;oacute; thể phối c&amp;ugrave;ng d&amp;acirc;y nịt tạo phong c&amp;aacute;ch chỉn chu khi đi l&amp;agrave;m.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Kiểu phối t&amp;uacute;i 2 b&amp;ecirc;n v&amp;agrave; 2 t&amp;uacute;i ở sau quần tạo điểm nhấn nổi bật, đem lại phong c&amp;aacute;ch năng động, nam t&amp;iacute;nh cho ph&amp;aacute;i mạnh.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Chất liệu vải kaki tho&amp;aacute;ng m&amp;aacute;t, tạo cảm gi&amp;aacute;c thoải m&amp;aacute;i khi mặc, cho bạn lu&amp;ocirc;n tự tin trong mọi vận động.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;M&amp;agrave;u sắc: m&amp;agrave;u da, m&amp;agrave;u đen.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;&lt;/div&gt;&lt;/div&gt;', 'Quần kaki nam xuất khẩu cao cấp', '', 'pending', 'open', 'open', '', 'quan-kaki-nam-xuat-khau-cao-cap', '', '', '2014-11-01 12:28:28', '', 0, 0, 'product', '', 0),
(1865, 13, '2014-11-01 16:13:04', '&lt;div id=&quot;middle_content&quot; class=&quot;expand&quot; style=&quot;overflow: hidden;&quot;&gt;&lt;div class=&quot;col_6_1 columm&quot;&gt;&lt;div class=&quot;deal_detail_Hi&quot;&gt;&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;Mũi N&amp;eacute; Paradise Resort &amp;amp; Spa&lt;/strong&gt;&amp;nbsp;tọa lạc tr&amp;ecirc;n đường Nguyễn Đ&amp;igrave;nh Chiểu gần trung t&amp;acirc;m mua sắm v&amp;agrave; nhiều dịch vụ ẩm thực, gần biển với nhiều b&amp;atilde;i tắm đẹp.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Resort c&amp;oacute; tổng cộng 36 ph&amp;ograve;ng nghỉ với đầy đủ trang thiết bị như tivi, m&amp;aacute;y điều h&amp;ograve;a, internet, v.v.&amp;nbsp;&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Tất cả c&amp;aacute;c ph&amp;ograve;ng của ch&amp;uacute;ng t&amp;ocirc;i đều c&amp;oacute; ban c&amp;ocirc;ng nh&amp;igrave;n ra biển v&amp;agrave; được bao bọc bởi một khu vườn nhiệt đới nhỏ xinh xắn.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Nh&amp;agrave; h&amp;agrave;ng tại resort với hướng nh&amp;igrave;n ra vườn chuy&amp;ecirc;n phục vụ c&amp;aacute;c m&amp;oacute;n ăn &amp;Aacute; - &amp;Acirc;u sẽ mang đến cho du kh&amp;aacute;ch một phong c&amp;aacute;ch thưởng thức ẩm thực cực kỳ độc đ&amp;aacute;o.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;B&amp;ecirc;n cạnh đ&amp;oacute; resort c&amp;ograve;n c&amp;oacute; b&amp;atilde;i biển ri&amp;ecirc;ng v&amp;agrave; bể bơi ngo&amp;agrave;i trời v&amp;agrave; nhiều dịch vụ tiện &amp;iacute;ch kh&amp;aacute;c gi&amp;uacute;p mang đến cho du kh&amp;aacute;ch một kỳ nghỉ thư gi&amp;atilde;n v&amp;agrave; thoải m&amp;aacute;i nhất.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Th&amp;ocirc;ng tin chi tiết vui l&amp;ograve;ng li&amp;ecirc;n hệ:&lt;/span&gt;&lt;/strong&gt;&lt;/li&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;MŨI N&amp;Eacute; PARADISE RESORT &amp;amp; SPA&lt;/strong&gt;&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Địa chỉ: 130C Nguyễn Đ&amp;igrave;nh Chiểu, H&amp;agrave;m Tiến, Phan Thiết.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Hotline hỗ trợ đặt tour/ ph&amp;ograve;ng/ v&amp;eacute; m&amp;aacute;y bay gi&amp;aacute; rẻ &amp;nbsp;(8h - 18h): 1900 6805. &lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Email : &lt;a href=&quot;mailto:booking@nhommua.com&quot;&gt;booking@nhommua.com&lt;/a&gt;&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Website: www.muineparadiseresort.com&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/ul&gt;&lt;/div&gt;&lt;/div&gt;&lt;/div&gt;', 'Mũi Né Paradise Resort &amp; Spa tiêu chuẩn 3*', '', 'timeout', 'open', 'open', '', 'mui-ne-paradise-resort-spa-tieu-chuan-3', '', '', '2014-11-01 16:13:04', '', 0, 0, 'product', '', 0),
(1866, 13, '2014-11-01 16:14:46', '&lt;h4&gt;Điểm nổi bật&lt;/h4&gt;&lt;ul&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;&lt;strong&gt;Kh&amp;aacute;ch sạn Lam Sơn Vũng T&amp;agrave;u&lt;/strong&gt; nằm tại trung t&amp;acirc;m du lịch b&amp;atilde;i trước, cạnh c&amp;aacute;c trung t&amp;acirc;m vui chơi giải tr&amp;iacute; nổi tiếng như: Greyhound, casino, c&amp;acirc;u lạc bộ disco, bar, n&amp;uacute;i lớn...&amp;nbsp;&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Đặc biệt kh&amp;aacute;ch sạn chỉ c&amp;aacute;ch b&amp;atilde;i biển 100m, đại lộ Quang Trung 100m v&amp;agrave; ga t&amp;agrave;u c&amp;aacute;nh ngầm Vũng T&amp;agrave;u khoảng 800m.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;C&amp;aacute;c ph&amp;ograve;ng đều c&amp;oacute; ban c&amp;ocirc;ng nh&amp;igrave;n ra b&amp;atilde;i biển, th&amp;agrave;nh phố hoặc n&amp;uacute;i, được trang bị đầy đủ c&amp;aacute;c tiện nghi m&amp;aacute;y lạnh, tủ lạnh, TV truyền h&amp;igrave;nh c&amp;aacute;p, bồn tắm hoặc v&amp;ograve;i hoa sen, giường nệm lớn, nước n&amp;oacute;ng lạnh...&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span style=&quot;font-size: small;&quot;&gt;Đa dạng c&amp;aacute;c dịch vụ tiện &amp;iacute;ch cho du kh&amp;aacute;ch như wifi miễn ph&amp;iacute;, truyền h&amp;igrave;nh c&amp;aacute;p, massage thư gi&amp;atilde;n, cho thu&amp;ecirc; xe, nh&amp;agrave; h&amp;agrave;ng, b&amp;atilde;i đậu xe,...&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;', 'Khách sạn Lam Sơn Vũng Tàu sát biển bãi trước', '', 'pending', 'open', 'open', '', 'khach-san-lam-son-vung-tau-sat-bien-bai-truoc', '', '', '2014-11-01 16:14:46', '', 0, 0, 'product', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bbv_product_step`
--

CREATE TABLE IF NOT EXISTS `bbv_product_step` (
`ID` int(11) NOT NULL,
  `stt` int(11) NOT NULL,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  `step` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `bbv_product_step`
--

INSERT INTO `bbv_product_step` (`ID`, `stt`, `min`, `max`, `step`) VALUES
(1, 0, 0, 2500000, 200000),
(5, 1, 2500000, 5500000, 500000),
(12, 2, 5500000, 20000000, 5000000),
(13, 3, 20000000, -8, 10000000);

-- --------------------------------------------------------

--
-- Table structure for table `bbv_terms`
--

CREATE TABLE IF NOT EXISTS `bbv_terms` (
`term_id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1219 ;

--
-- Dumping data for table `bbv_terms`
--

INSERT INTO `bbv_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1211, 'Danh mục 2', 'danh-muc-2', 0),
(1, 'Danh mục 1', 'danh-muc-1', 0),
(1213, 'tin tuc hay', 'tin-tuc-hay', 0),
(1218, 'Danh mục 3', 'danh-muc-3', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bbv_term_relationships`
--

CREATE TABLE IF NOT EXISTS `bbv_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bbv_term_relationships`
--

INSERT INTO `bbv_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1768, 1213, 0),
(1768, 1209, 0),
(1767, 1209, 0),
(1767, 1212, 0),
(1766, 1209, 0),
(1766, 1211, 0),
(1765, 1, 0),
(1839, 1216, 0),
(1840, 1, 0),
(1841, 1216, 0),
(1842, 1209, 0),
(1843, 1216, 0),
(1211, 1209, 0),
(1844, 1, 0),
(1, 1, 0),
(1845, 1216, 0),
(1846, 1216, 0),
(1218, 1216, 0),
(1847, 1, 0),
(1848, 1, 0),
(1849, 1, 0),
(1850, 1209, 0),
(1851, 1209, 0),
(1852, 1216, 0),
(1853, 1216, 0),
(1854, 1216, 0),
(1855, 1216, 0),
(1856, 1216, 0),
(1857, 1, 0),
(1858, 1216, 0),
(1859, 1, 0),
(1860, 1209, 0),
(1861, 1, 0),
(1862, 1216, 0),
(1863, 1209, 0),
(1864, 1, 0),
(1865, 1, 0),
(1866, 1209, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bbv_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `bbv_term_taxonomy` (
`term_taxonomy_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1217 ;

--
-- Dumping data for table `bbv_term_taxonomy`
--

INSERT INTO `bbv_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1209, 1211, 'category', '', 0, 0),
(1211, 1213, 'post_tag', '', 0, 0),
(1, 1, 'category', '', 0, 0),
(1212, 1214, 'post_tag', '', 0, 0),
(1213, 1215, 'post_tag', '', 0, 0),
(1214, 1216, 'post_tag', '', 0, 0),
(1216, 1218, 'category', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bbv_theme_options`
--

CREATE TABLE IF NOT EXISTS `bbv_theme_options` (
`box_id` int(11) NOT NULL,
  `stt` int(11) DEFAULT NULL,
  `box_type` varchar(45) COLLATE utf8_unicode_ci DEFAULT 'category',
  `object_id` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bbv_theme_options`
--

INSERT INTO `bbv_theme_options` (`box_id`, `stt`, `box_type`, `object_id`) VALUES
(1, 0, 'category', 1211),
(2, 1, 'category', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bbv_commentmeta`
--
ALTER TABLE `bbv_commentmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `comment_id` (`comment_id`), ADD KEY `meta_key` (`meta_key`);

--
-- Indexes for table `bbv_comments`
--
ALTER TABLE `bbv_comments`
 ADD PRIMARY KEY (`comment_ID`), ADD KEY `comment_post_ID` (`comment_post_ID`), ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`), ADD KEY `comment_date_gmt` (`comment_date_gmt`), ADD KEY `comment_parent` (`comment_parent`);

--
-- Indexes for table `bbv_login_confirm`
--
ALTER TABLE `bbv_login_confirm`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bbv_login_integration`
--
ALTER TABLE `bbv_login_integration`
 ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `bbv_login_levels`
--
ALTER TABLE `bbv_login_levels`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `level_level` (`level_level`);

--
-- Indexes for table `bbv_login_timestamps`
--
ALTER TABLE `bbv_login_timestamps`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bbv_login_users`
--
ALTER TABLE `bbv_login_users`
 ADD PRIMARY KEY (`user_id`), ADD UNIQUE KEY `user_id` (`user_id`), ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `bbv_members_meta`
--
ALTER TABLE `bbv_members_meta`
 ADD PRIMARY KEY (`umeta_id`);

--
-- Indexes for table `bbv_options`
--
ALTER TABLE `bbv_options`
 ADD PRIMARY KEY (`option_id`), ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `bbv_postmeta`
--
ALTER TABLE `bbv_postmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `post_id` (`post_id`), ADD KEY `meta_key` (`meta_key`);

--
-- Indexes for table `bbv_posts`
--
ALTER TABLE `bbv_posts`
 ADD PRIMARY KEY (`ID`), ADD KEY `post_name` (`post_name`), ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`), ADD KEY `post_parent` (`post_parent`), ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `bbv_product_step`
--
ALTER TABLE `bbv_product_step`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `bbv_product_stepcol_UNIQUE` (`stt`);

--
-- Indexes for table `bbv_terms`
--
ALTER TABLE `bbv_terms`
 ADD PRIMARY KEY (`term_id`), ADD UNIQUE KEY `slug` (`slug`), ADD KEY `name` (`name`);

--
-- Indexes for table `bbv_term_relationships`
--
ALTER TABLE `bbv_term_relationships`
 ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`), ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `bbv_term_taxonomy`
--
ALTER TABLE `bbv_term_taxonomy`
 ADD PRIMARY KEY (`term_taxonomy_id`), ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`), ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `bbv_theme_options`
--
ALTER TABLE `bbv_theme_options`
 ADD PRIMARY KEY (`box_id`), ADD UNIQUE KEY `object_id_UNIQUE` (`object_id`), ADD UNIQUE KEY `stt_UNIQUE` (`stt`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bbv_commentmeta`
--
ALTER TABLE `bbv_commentmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bbv_comments`
--
ALTER TABLE `bbv_comments`
MODIFY `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=89;
--
-- AUTO_INCREMENT for table `bbv_login_confirm`
--
ALTER TABLE `bbv_login_confirm`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bbv_login_levels`
--
ALTER TABLE `bbv_login_levels`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `bbv_login_timestamps`
--
ALTER TABLE `bbv_login_timestamps`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bbv_login_users`
--
ALTER TABLE `bbv_login_users`
MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `bbv_members_meta`
--
ALTER TABLE `bbv_members_meta`
MODIFY `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `bbv_options`
--
ALTER TABLE `bbv_options`
MODIFY `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7173;
--
-- AUTO_INCREMENT for table `bbv_postmeta`
--
ALTER TABLE `bbv_postmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31039;
--
-- AUTO_INCREMENT for table `bbv_posts`
--
ALTER TABLE `bbv_posts`
MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1867;
--
-- AUTO_INCREMENT for table `bbv_product_step`
--
ALTER TABLE `bbv_product_step`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `bbv_terms`
--
ALTER TABLE `bbv_terms`
MODIFY `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1219;
--
-- AUTO_INCREMENT for table `bbv_term_taxonomy`
--
ALTER TABLE `bbv_term_taxonomy`
MODIFY `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1217;
--
-- AUTO_INCREMENT for table `bbv_theme_options`
--
ALTER TABLE `bbv_theme_options`
MODIFY `box_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
